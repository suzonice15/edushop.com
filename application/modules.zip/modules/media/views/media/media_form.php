	<div class="box-body">
		<div class="form-group "><label for="media_title">Media Title<span class="required">*</span></label>
			<input
				type="text" required class="form-control" name="media_title" id="media_title" value=""></div>
		<div class="form-group featured-image">
			<label>Media File<span class="required">*</span></label>
			<input required
				type="file" class="form-control" name="featured_image"></div>
	</div>
