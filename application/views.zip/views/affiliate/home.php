<?php $this->load->view('website/header');?>



	<div class="container-fluid" style="margin-bottom: 70px;">
	<div class="row">
		
			
			
<?php $this->load->view('affiliate/sideber');?>
			
				
<?php echo $home;?>
				
			
	</div>
	</div>
	








<?php $this->load->view('website/footer');?>
