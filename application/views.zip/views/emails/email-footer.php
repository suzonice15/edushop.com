				<table border="0" cellpadding="10" cellspacing="0" width="600" >                
					<tr>
                 		<td valign="top" align="center" style="padding:20px 0; color:#999999;font-family:Tahoma,Arial,sans-serif;font-size:12px;font-weight:normal;line-height:20px;text-align:center; background:#eeeeee;">
                 			<?=get_option('copyright')?> | Powered By <a href="http://isolutionsbd.com/">isolutions</a>
                 		</td>
                 	</tr>
				</table>
			</td>
		</tr>
	</table>
</div>
</body>
</html>